$(function(){
    var base_url = $("[name=base_url]").attr('content');
    var site_url = $("[name=site_url]").attr('content');
    $(".ajaxForm").submit(function(e){
        e.preventDefault();
        $(this).validate({
            submitHandler: function(form){
                //form.submit();
                $.ajax({
                    url: $(form).attr('action'),
                    type: 'post',
                    data: $(form).serialize(),
                    success: function(data){
                        $("#content").html(data);
                        //alert('اطلاعات با موفقیت ثبت گردید');
                    }
                });
            }
        });
    });
    
	$(":text").attr('autocomplete', false);
    
	$(".ajaxForm input[type=text],form input[type=password]").addClass("ui-corner-all");
    
	$(".ui-jqdialog").position({
        my: "center",
        at: "center",
        of: window
    });
    
	$(".menu-item a").click(function(e){
        /*e.preventDefault();
         $.get($(this).attr('href'), function(data){
         $('#content').html($('#content', data))
         });*/
    });
});
